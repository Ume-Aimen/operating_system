#include <stdio.h>    // For input/output functions like printf, fgets, fprintf
#include <stdlib.h>   // For general-purpose utilities like exit codes
#include <string.h>   // For string operations like strcmp and strcspn

/*
 * This task simulates a simple notepad application.
 * The user types notes line by line, and each line is automatically saved to "notes.txt".
 * Typing ':q' exits the notepad. The file remains open during input and is saved continuously.
 */

int main() {
    char line[1024];
    FILE *file = fopen("notes.txt", "a"); // Open file in append mode

    if (file == NULL) {
        printf("Failed to open notes.txt for writing.\n");
        return 1;
    }

    printf("Welcome to Notepad Task\n");
    printf("Type your notes below. Type ':q' to exit.\n");

    while (1) {
        printf("> ");
        fgets(line, sizeof(line), stdin);

        // Remove the newline character at the end of input
        line[strcspn(line, "\n")] = '\0';

        if (strcmp(line, ":q") == 0) {
            break; // Exit loop if user types :q
        }

        fprintf(file, "%s\n", line); // Write the line to the file
        fflush(file);                // Immediately save (autosave)
        printf("[Auto-saved]\n");
    }

    fclose(file);
    printf("Notepad closed. Notes saved to notes.txt.\n");
    return 0;
}

