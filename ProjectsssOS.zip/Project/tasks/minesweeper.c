#include <stdio.h>   // For input/output functions like printf, scanf
#include <stdlib.h>  // For rand(), srand()
#include <time.h>    // For time() to seed random number generator

/*
 * This task is a simplified 3x3 text-based Minesweeper game.
 * One mine is placed randomly on the board.
 * The player makes 3 moves by entering row and column values.
 * If they hit the mine, the game ends. If they avoid it for 3 turns, they win.
 */

char board[3][3];
int mineRow, mineCol;

// Draws the game board.
// If `reveal` is 1, show the full board (including the mine).
// If `reveal` is 0, hide unrevealed cells as underscores.
void drawBoard(int reveal) {
    printf("\nBoard:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (reveal || board[i][j] != '_')
                printf(" %c ", board[i][j]);
            else
                printf(" _ ");
        }
        printf("\n");
    }
}

int main() {
    int row, col;

    // Seed the random number generator and choose random mine location
    srand(time(NULL));
    mineRow = rand() % 3;
    mineCol = rand() % 3;

    // Initialize the 3x3 board with underscores
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            board[i][j] = '_';

    printf("Minesweeper Task: Safe cells marked with 'O'.\n");
    printf("Try to survive 3 moves without hitting the mine.\n");

    for (int moves = 0; moves < 3; moves++) {
        drawBoard(0);
        printf("Move #%d — Enter row and column (0–2): ", moves + 1);
        scanf("%d %d", &row, &col);

        if (row == mineRow && col == mineCol) {
            printf("💥 You hit a mine! Game Over.\n");
            board[row][col] = 'X';
            drawBoard(1);
            return 0;
        } else {
            board[row][col] = 'O';
        }
    }

    printf("🎉 You survived! You win.\n");
    drawBoard(1);
    return 0;
}

