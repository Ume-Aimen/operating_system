#include <stdio.h>   // For input/output functions like printf, scanf, fopen, fgets, fputs
#include <stdlib.h>  // For general-purpose utilities like exit codes

/*
 * This task copies the contents of one file to another.
 * The user is prompted to enter the source file name and the destination file name.
 * The program reads the source file line by line and writes each line to the destination file.
 * It handles file opening errors and ensures both files are properly closed after copying.
 */

int main() {
    char source[100], destination[100];
    char buffer[1024];

    printf("Enter source file name: ");
    scanf("%s", source);
    printf("Enter destination file name: ");
    scanf("%s", destination);

    FILE *src = fopen(source, "r");
    if (!src) {
        printf("Source file not found!\n");
        return 1;
    }

    FILE *dest = fopen(destination, "w");
    if (!dest) {
        printf("Failed to create destination file!\n");
        fclose(src);
        return 1;
    }

    while (fgets(buffer, sizeof(buffer), src)) {
        fputs(buffer, dest);
    }

    fclose(src);
    fclose(dest);
    printf("File copied successfully.\n");
    return 0;
}

