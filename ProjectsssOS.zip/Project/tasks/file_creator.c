#include <stdio.h>   // For input/output functions like printf, scanf, fopen, fgets, fputs
#include <stdlib.h>  // For general-purpose utilities like perror and exit

/*
 * This task allows the user to create a new file and write content to it.
 * The user is prompted to enter the file name and then type lines of content.
 * Input ends when the user types a tilde (~) on a new line.
 * The content is written to the file in real-time, and the file is saved when done.
 */

int main() {
    char filename[100], content[1024];
    
    printf("Enter filename to create: ");
    scanf("%s", filename);

    getchar(); // Clear newline character left by scanf

    printf("Enter content (end input with ~ on a new line):\n");

    FILE *fp = fopen(filename, "w");
    if (fp == NULL) {
        perror("File creation failed");
        return 1;
    }

    while (fgets(content, sizeof(content), stdin)) {
        if (content[0] == '~') break; // End input if ~ is typed
        fputs(content, fp);           // Write line to file
    }

    fclose(fp);
    printf("File '%s' created and saved successfully.\n", filename);
    return 0;
}

