#include <stdio.h>     // For input/output functions like printf
#include <stdlib.h>    // For general-purpose utilities (optional here)
#include <unistd.h>    // For sleep() function
#include <time.h>      // For working with system time and formatting it

/*
 * This is a simple real-time Clock Task that runs in an infinite loop.
 * It fetches and displays the current system time every second.
 * The user can exit the task manually using Ctrl+C (SIGINT).
 */

int main() {
    printf("Clock Task Started. Press Ctrl+C to exit.\n");

    while (1) {
        time_t t;
        struct tm *tm_info;
        char buffer[30];

        time(&t);                           // Get current time in seconds
        tm_info = localtime(&t);           // Convert to local time structure
        strftime(buffer, 30, "%Y-%m-%d %H:%M:%S", tm_info); // Format date/time as string

        printf("Current Time: %s\n", buffer);
        sleep(1);                          // Wait for 1 second before updating again
    }

    return 0;
}

