#include <stdio.h>    // For input/output functions like printf
#include <unistd.h>   // For sleep() and fflush() to control timing and output behavior

/*
 * This task simulates a music player by printing a message and playing
 * a beep sound every second for 10 seconds.
 * Each beep represents a sound note, and the task runs automatically.
 */

int main() {
    printf("Music Player Task Running...\n");
    for (int i = 0; i < 10; i++) {
        printf("♪ Playing sound %d\n", i + 1);
        printf("\a");  // Produces a beep sound (may not work in all terminals)
        fflush(stdout); // Ensures the message is printed before the sleep delay
        sleep(1);       // Waits for 1 second before the next sound
    }
    printf("Music finished.\n");
    return 0;
}

