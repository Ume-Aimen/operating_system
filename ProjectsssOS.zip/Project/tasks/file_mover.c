#include <stdio.h>   // For input/output functions like printf and scanf
#include <stdlib.h>  // For the rename() function and error reporting with perror

/*
 * This task allows the user to move (rename) a file from one name to another.
 * It takes the source and destination file names as input and uses the rename() function.
 * If successful, the file is moved. If not, an error message is shown.
 */

int main() {
    char source[100], destination[100];

    printf("Enter source file name: ");
    scanf("%s", source);

    printf("Enter destination file name: ");
    scanf("%s", destination);

    if (rename(source, destination) == 0) {
        printf("File moved successfully from '%s' to '%s'.\n", source, destination);
    } else {
        perror("Error moving file");
    }

    return 0;
}

