#include <stdio.h>
#include <unistd.h>

int main() {
    int seconds;

    printf("Enter countdown time (in seconds): ");
    scanf("%d", &seconds);

    for (int i = seconds; i > 0; i--) {
        printf("Time remaining: %d seconds\n", i);
        sleep(1);
    }

    printf("Time's up!\n");
    return 0;
}
