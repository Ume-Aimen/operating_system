#include <stdio.h>    // For input/output functions like printf and scanf
#include <stdlib.h>   // For general-purpose functions (not strictly needed here but good practice)

/*
 * This is a simple calculator task that runs continuously in a loop.
 * It allows the user to input two integers and an operator (+, -, *, /),
 * performs the calculation, and prints the result.
 * If the operator is unknown or division by zero is attempted, it shows an error message.
 */

int main() {
    int a, b;
    char op;

    printf("Calculator Task Started\n");

    while (1) {
        printf("Enter operation (e.g., 2 + 3): ");
        scanf("%d %c %d", &a, &op, &b);

        switch (op) {
            case '+': printf("Result: %d\n", a + b); break;
            case '-': printf("Result: %d\n", a - b); break;
            case '*': printf("Result: %d\n", a * b); break;
            case '/': 
                if (b == 0) printf("Cannot divide by zero\n");
                else printf("Result: %d\n", a / b);
                break;
            default: printf("Unknown operator\n");
        }
    }
}

