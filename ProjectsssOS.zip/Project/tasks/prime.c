#include <stdio.h>  // For input/output functions like printf and scanf

/*
 * This task checks whether a number entered by the user is a prime number.
 * A prime number is only divisible by 1 and itself.
 * The program prints whether the number is prime or not based on the check.
 */

int main() {
    int num, i, isPrime = 1;

    printf("Enter a number to check if it's prime: ");
    scanf("%d", &num);

    if (num <= 1) {
        isPrime = 0;  // Numbers <= 1 are not prime
    } else {
        // Check divisibility from 2 to sqrt(num)
        for (i = 2; i * i <= num; i++) {
            if (num % i == 0) {
                isPrime = 0;
                break;
            }
        }
    }

    // Output result
    if (isPrime)
        printf("%d is a Prime number.\n", num);
    else
        printf("%d is NOT a Prime number.\n", num);

    return 0;
}

