#include <stdio.h>         // For input/output functions like printf
#include <stdlib.h>        // For general-purpose utilities like exit codes
#include <sys/statvfs.h>   // For accessing file system statistics

/*
 * This task displays disk space information for the current directory.
 * It uses the statvfs() function to retrieve the file system's total,
 * used, and available space and prints them in gigabytes.
 */

int main() {
    struct statvfs stats;

    // Get filesystem statistics for the current directory
    if (statvfs(".", &stats) != 0) {
        perror("statvfs failed"); // Show error if the call fails
        return 1;
    }

    // Calculate total, free, and used disk space in bytes
    unsigned long total = stats.f_blocks * stats.f_frsize;
    unsigned long free = stats.f_bfree * stats.f_frsize;
    unsigned long used = total - free;

    // Display the information in gigabytes
    printf("Disk Space Info (Current Drive):\n");
    printf("Total: %.2f GB\n", total / (1024.0 * 1024 * 1024));
    printf("Used : %.2f GB\n", used / (1024.0 * 1024 * 1024));
    printf("Free : %.2f GB\n", free / (1024.0 * 1024 * 1024));

    return 0;
}

