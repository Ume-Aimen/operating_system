#include <stdio.h>  // For input/output functions like printf and scanf

/*
 * This task calculates the factorial of a number entered by the user.
 * It checks for negative input (factorial is undefined) and uses a loop
 * to compute the product from 1 to the entered number.
 */

int main() {
    int num;
    long long fact = 1;

    printf("Enter a number to find its factorial: ");
    scanf("%d", &num);

    if (num < 0) {
        printf("Factorial not defined for negative numbers.\n");
        return 1;
    }

    for (int i = 1; i <= num; i++) {
        fact *= i;
    }

    printf("Factorial of %d is %lld\n", num, fact);
    return 0;
}

