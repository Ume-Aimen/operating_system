#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

// Function that runs in a separate thread
void* showTime(void* arg) {
    for (int i = 0; i < 5; i++) {
        time_t now = time(NULL);
        struct tm* t = localtime(&now);
        printf("Current Time: %02d:%02d:%02d\n", 
               t->tm_hour, t->tm_min, t->tm_sec);
        sleep(1);
    }
    printf("Clock thread finished.\n");
    return NULL;
}

int main() {
    pthread_t tid;
    printf("Clock Task Started (Thread-Based)\n");

    // Create and run the thread
    if (pthread_create(&tid, NULL, showTime, NULL) != 0) {
        perror("Failed to create thread");
        return 1;
    }

    // Wait for the thread to finish
    pthread_join(tid, NULL);
    printf("Clock Task Ended.\n");

    return 0;
}

