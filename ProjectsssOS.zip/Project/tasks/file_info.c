#include <stdio.h>      // For input/output functions like printf and scanf
#include <stdlib.h>     // For general-purpose utilities like perror
#include <sys/stat.h>   // For retrieving file information (size, timestamps)
#include <time.h>       // For formatting time values (ctime)

/*
 * This task displays information about a specific file entered by the user.
 * It uses the stat() function to get details like file size, creation time,
 * and last modification time. If the file doesn’t exist, an error is shown.
 */

int main() {
    char filename[100];
    struct stat st;

    printf("Enter filename to check: ");
    scanf("%s", filename);

    if (stat(filename, &st) == 0) {
        printf("\nFile Info:\n");
        printf("Size: %ld bytes\n", st.st_size);
        printf("Created: %s", ctime(&st.st_ctime));
        printf("Last modified: %s", ctime(&st.st_mtime));
    } else {
        perror("Error getting file info");
    }

    return 0;
}

