#include <stdio.h>   // For input/output functions like printf and scanf
#include <stdlib.h>  // For the remove() function and error reporting with perror

/*
 * This task allows the user to delete a file from the system.
 * The user is prompted to enter the file name.
 * If the file exists, it is removed using the remove() function.
 * If the file cannot be deleted (e.g., it doesn’t exist), an error message is shown.
 */

int main() {
    char filename[100];

    printf("Enter filename to delete: ");
    scanf("%s", filename);

    if (remove(filename) == 0) {
        printf("File '%s' deleted successfully.\n", filename);
    } else {
        perror("Error deleting file");
    }

    return 0;
}

